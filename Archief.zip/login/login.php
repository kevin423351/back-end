<?php
include'../database.php';
session_start();

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
if (isset($_POST['login'])) {
  $email = test_input($_POST['email']);
  $password = test_input($_POST['password']);

  $sql = "SELECT id FROM users WHERE email = '$email' AND password = '$password' AND active = 1";

  $result = mysqli_query($conn, $sql);

  if (mysqli_num_rows($result) > 0) {
    $_SESSION['login_active'] = [$email, $password];
    header("Location: overview_admin.php");
    exit();
  } else {
    $_SESSION['errors'] = "Login Error! Check Email & Password";
    header("Location: index.php");
    exit();
  }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/style.css">
  <title>Login</title>
</head>
<body class="">
  <div class="container  text-center d-flex align-items-center min-vh-100">
    <div class="card mx-auto py-5" style="width: 25rem;">
      <h1>Login</h1>
      <div class="card-body">
        <form action="" method="post">
          <div class="mb-2">
            <label for="email" class="form-label">Email address</label>
            <input type="email" class="form-control" id="email" name="email" required>
          </div>
          <div class="mb-2">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" id="password" name="password" required>
          </div>
          <button type="submit" class="btn btn-primary" name="login">Login</button>
        </form>
      </div>
    </div>
  </div>
</body>
</html>