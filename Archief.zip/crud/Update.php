<?php
include "../database.php";
    if (isset($_POST['Update'])) {
        $ID = test_input($_GET['ID']);
        $vraag1 = test_input($_POST['vraag1']);
        $vraag2 = test_input($_POST['vraag2']);
        $vraag3 = test_input($_POST['vraag3']);
        $vraag4 = test_input($_POST['vraag4']);
        $vraag5 = test_input($_POST['vraag5']);
        $vraag6 = test_input($_POST['vraag6']);
        $vraag7 = test_input($_POST['vraag7']);
        $vraag8 = test_input($_POST['vraag8']);

        $sql = "UPDATE `mad_libs` SET `vraag1`='$vraag1', `vraag2`='$vraag2', `vraag3`='$vraag3', `vraag4`='$vraag4', `vraag5`='$vraag5', `vraag6`='$vraag6', `vraag7`='$vraag7', `vraag8`='$vraag8' WHERE ID='".$ID."'"; 
  
        $result = $conn->query($sql); 

        if($result){
            header('location:overview.php');
        }
    } 

if (isset($_GET['ID'])) {
    $ID = $_GET['ID']; 
    $sql = "SELECT * FROM `mad_libs` WHERE ID='".$ID."'";
    $result = $conn->query($sql); 
    if ($result->num_rows > 0) {        
        while ($row = $result->fetch_assoc()) {
            $vraag1 = $row['vraag1'];
            $vraag2 = $row['vraag2'];
            $vraag3 = $row['vraag3'];
            $vraag4 = $row['vraag4'];
            $vraag5 = $row['vraag5'];
            $vraag6 = $row['vraag6'];
            $vraag7 = $row['vraag7'];
            $vraag8 = $row['vraag8'];
        } 
    }
}
function test_input($data) {
    $data = trim($data);
    $data = addslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="uft-8">
    <meta http-equiv="X-UA-compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>mad libs</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
  <div class="container">
    <div class="title"> 
      <h1>mad libs</h1>
    </div>
    <div class="main">
    <nav class="app__nav">
      <a href="paniek.php">Er heerst paniek...</a>
      <a href="onkunde.php">Onkunde</a>
    </nav>
      <h2>Er heerst paniek</h2>
      <form action="" method="POST">
        Welk dier je nooit als huisdier willen hebben? <input type="text" id="vraag1" name="vraag1" value="<?php echo $vraag1; ?>"/>
        <br>
        Wie is de balangrijkste persoon in je leven? <input type="text" id="vraag2" name="vraag2" value="<?php echo $vraag2; ?>"/>
        <br>
        In welk land zou je graag willen wonen <input type="text" id="vraag3" name="vraag3" value="<?php echo $vraag3; ?>"/>
        <br>
        Wat doe je als je je verveelt <input type="text" id="vraag4" name="vraag4" value="<?php echo $vraag4; ?>"/>
        <br>
        met welk speelgoed speelde je als kind het meest? <input type="text" id="vraag5" name="vraag5" value="<?php echo $vraag5; ?>"/>
        <br>
        Bij welke docent spijbel je het liefst <input type="text" id="vraag6" name="vraag6" value="<?php echo $vraag6; ?>"/>
        <br>
        Als je $ 100.000,- had, wat zou je dan kopen <input type="text" id="vraag7" name="vraag7" value="<?php echo $vraag7; ?>"/>
        <br>
        Wat is favoriete bezigheid? <input type="text" id="vraag8" name="vraag8" value="<?php echo $vraag8; ?>"/>
        <br>
        <input type="submit" value="Update" name="Update">
      </form>
    </div>
  </div>
</body>
</html>


 