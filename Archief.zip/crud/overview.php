<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../css/bootstrap.min.css">
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php
    include '../database.php';
        $getdata = 'SELECT * FROM mad_libs';
        $result = mysqli_query($conn, $getdata);
        $contact = mysqli_fetch_all($result, MYSQLI_ASSOC);
        mysqli_free_result($result);
    ?>
<div class="container2">  
    <button class="btn btn-primary my-4"><a href="paniek.php" class="text-light">Vul het veld opnieuw in</a></button>
        <div class="overview">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">vraag 1</th>
                        <th scope="col">vraag 2</th>
                        <th scope="col">vraag 3</th>
                        <th scope="col">vraag 4</th>
                        <th scope="col">vraag 5</th>
                        <th scope="col">vraag 6</th>
                        <th scope="col">vraag 7</th>
                        <th scope="col">vraag 8</th>
                    </tr>
                </thead>
                <?php foreach ($contact as $contacts) { ?> 
                <tbody>
                    <tr>
                        <th><?php echo stripslashes($contacts['ID']); ?></th>
                        <td><?php echo stripslashes($contacts['vraag1']); ?></td>
                        <td><?php echo stripslashes($contacts['vraag2']); ?></td>
                        <td><?php echo stripslashes($contacts['vraag3']); ?></td>
                        <td><?php echo stripslashes($contacts['vraag4']); ?></td>
                        <td><?php echo stripslashes($contacts['vraag5']); ?></td>
                        <td><?php echo stripslashes($contacts['vraag6']); ?></td>
                        <td><?php echo stripslashes($contacts['vraag7']); ?></td>
                        <td><?php echo stripslashes($contacts['vraag8']); ?></td>
                        <td><button class="btn btn-primary"><a href="Update.php?ID=<?php echo $contacts['ID']; ?>" class="text-light">Update</a></button></td>
                        <td><button class="btn btn-danger"><a href="Delete.php?ID=<?php echo $contacts['ID']; ?>" class="text-light">Delete</a></button></td>
                    </tr>
                </tbody>
                <?php } ?>
            </table>
        </div>
    </div>
</body>
</html>