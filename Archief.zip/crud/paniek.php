<?php
include'../database.php';

if (isset($_POST[submit]) && $_POST['vraag1'] !='' && $_POST['vraag2'] !='' && $_POST['vraag3'] !='' && $_POST['vraag4'] !='' && $_POST['vraag5'] !='' && $_POST['vraag6'] !='' && $_POST['vraag7'] !='' && $_POST['vraag8'] !=''){
  $vraag1 = test_input($_POST['vraag1']);
  $vraag2 = test_input($_POST['vraag2']);
  $vraag3 = test_input($_POST['vraag3']);
  $vraag4 = test_input($_POST['vraag4']);
  $vraag5 = test_input($_POST['vraag5']);
  $vraag6 = test_input($_POST['vraag6']);
  $vraag7 = test_input($_POST['vraag7']);
  $vraag8 = test_input($_POST['vraag8']);

  $sql = "INSERT INTO `mad_libs` (`vraag1`, `vraag2`, `vraag3`, `vraag4`, `vraag5`, `vraag6`, `vraag7`, `vraag8`)
  VALUES ('".$vraag1."', '".$vraag2."', '".$vraag3."', '".$vraag4."', '".$vraag5."', '".$vraag6."', '".$vraag7."', '".$vraag8."')";

  if ($conn->query($sql)=== TRUE){
    echo " inserted succesfully";
  } else { 
    echo "Error: " .$sql . "<br>" . $conn->error;
  }
}else  {
  echo 'field is required';
}


function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="uft-8">
    <meta http-equiv="X-UA-compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>mad libs</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
  <div class="container">
    <div class="title"> 
      <h1>mad libs</h1>
    </div>
    <div class="main">
    <nav class="app__nav">
      <a href="paniek.php">Er heerst paniek...</a>
      <a href="onkunde.php">Onkunde</a>
    </nav>
      <h2>Er heerst paniek</h2>
      <form action="" method="POST">
        Welk dier je nooit als huisdier willen hebben? <input type="text" id="vraag1" name="vraag1" value="<?php echo $vraag1; ?>"/>
        <br>
        Wie is de balangrijkste persoon in je leven? <input type="text" id="vraag2" name="vraag2" value="<?php echo $vraag2; ?>"/>
        <br>
        In welk land zou je graag willen wonen <input type="text" id="vraag3" name="vraag3" value="<?php echo $vraag3; ?>"/>
        <br>
        Wat doe je als je je verveelt <input type="text" id="vraag4" name="vraag4" value="<?php echo $vraag4; ?>"/>
        <br>
        met welk speelgoed speelde je als kind het meest? <input type="text" id="vraag5" name="vraag5" value="<?php echo $vraag5; ?>"/>
        <br>
        Bij welke docent spijbel je het liefst <input type="text" id="vraag6" name="vraag6" value="<?php echo $vraag6; ?>"/>
        <br>
        Als je $ 100.000,- had, wat zou je dan kopen <input type="text" id="vraag7" name="vraag7" value="<?php echo $vraag7; ?>"/>
        <br>
        Wat is favoriete bezigheid? <input type="text" id="vraag8" name="vraag8" value="<?php echo $vraag8; ?>"/>
        <br>
        <input type="submit" name="submit" value="submit">
      </form>
    </div>
  </div>
</body>
</html>


 