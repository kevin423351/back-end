<?php
include '../database.php';
if(isset($_GET['ID'])){
    $ID=$_GET['ID'];

    $sql="DELETE from `mad_libs` where ID='".$ID."'";
    $result=mysqli_query($conn,$sql);
    if($result){
        header('location:overview.php');
    } else{
        die(mysqli_error($conn));
    }
}
?>