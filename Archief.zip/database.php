<?php
$dbhost = "localhost";
$dbuser = "webmakers_kevinshelterpoint";
$dbpass = "9nzK3ghuor";
$db = "webmakers_kevinshelterpoint";

$conn = new mysqli($dbhost, $dbuser, $dbpass, $db);
$conn->select_db("webmakers_kevinshelterpoint");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

?>