<!DOCTYPE html>
<html lang="en">
  <head>
      <meta charset="uft-8">
      <meta http-equiv="X-UA-compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>mad libs</title>
      <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    <div class="container">
      <div class="title"> 
        <h1>mad libs</h1>
      </div>
      <div class="main">
      <nav class="app__nav">
        <a href="paniek.php">Er heerst paniek...</a>
        <a href="onkunde.php">Onkunde</a>
      </nav>
        <h2>Onkunde</h2> 
        <form action="onkunde2.php" method="POST">
          Wat zou je graag willen kunnen? <input type="text" id="vraag1" name="vraag1"/>
          <br>
          Met welke persoon kun je goed opschieten? <input type="text" id="vraag2" name="vraag2"/>
          <br>
          Wat is je favoriete getal? <input type="text" id="vraag3" name="vraag3"/>
          <br>
          Wat heb je altijd bij je als je op vakantie gaat? <input type="text" id="vraag4" name="vraag4"/>
          <br>
          Wat is je beste persoonlijke eigenschap <input type="text" id="vraag5" name="vraag5"/>
          <br>
          Wat is je slechtste persoonlijkeeigenschap? <input type="text" id="vraag6" name="vraag6"/>
          <br>
          Wat is het ergste dat je kan overkomen? <input type="text" id="vraag7" name="vraag7"/>
          <br>
          Wat is favoriete bezigheid? <input type="text" id="vraag8" name="vraag8"/>
          <br>
          <input type="submit" value="submit">
        </form>
      </div>
    </div>
  </body>
</html>