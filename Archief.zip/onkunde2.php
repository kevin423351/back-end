<?php

$vraag1 = $_POST['vraag1'];
$vraag2 = $_POST['vraag2'];
$vraag3 = $_POST['vraag3'];
$vraag4 = $_POST['vraag4'];
$vraag5 = $_POST['vraag5'];
$vraag6 = $_POST['vraag6'];
$vraag7 = $_POST['vraag7'];
$vraag8 = $_POST['vraag8'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="uft-8">
    <meta http-equiv="X-UA-compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>mad libs</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <div class="title"> 
        <h1>mad libs</h1>
        </div>
        <div class="main2">
            <nav class="app__nav">
                <a href="paniek.php">Er heerst paniek...</a>
                <a href="onkunde.php">Onkunde</a>
            </nav>
        <h2>onkunde</h2>
          <div class="element">
            <?php
            echo'Er was eens een '.$vraag1.' genaamd Fluffy. Fluffy was niet zomaar een konijn, nee, hij was een superheldenkonijn! Elke dag trok hij zijn cape aan en ging hij de wereld redden van het kwaad.

            Op een dag besloot Fluffy om de stad te redden van een grote '.$vraag2.'. Hij rende naar de rivier, pakte een emmer en begon het water weg te scheppen. Maar hoe harder hij werkte, hoe hoger het water steeg.
            
            Plotseling hoorde '.$vraag3.' een stem achter hem zeggen: "Hé, wat ben je aan het doen?" '.$vraag4.' draaide zich om en zag een kikker staan.
            
            Ik ben de stad aan het redden van een '.$vraag5.'! antwoordde Fluffy trots.
            
            De kikker keek naar de emmer in '.$vraag6.' pootjes en zei: Weet je, als je gewoon een dam bouwt, dan kan je het water '.$vraag7.'.
            
            Fluffy keek naar de '.$vraag8.' en dacht: Waarom heb ik daar niet eerder aan gedacht? Een dam bouwen is veel makkelijker dan water wegscheppen';
            ?>
          </div>
        </div>
    </div>
</body>